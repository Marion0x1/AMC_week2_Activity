import React from 'react' ;
import {View, Text, Image, ScrollView, TextInput} from 'react-native' ;

const App = () => {
  return (
    <ScrollView>
    <View style={{
    justifyContent: 'center',
    alignItems: 'center',
    }}>
   
    <Text> Marion Mizona</Text>
   
    <Text> React Practice</Text>
    <Image
    source={{
      uri:'https://i.ytimg.com/vi/lyH6yzmgamo/maxresdefault.jpg',
    }}
    style={{width: 200, height: 200}}
    />
    </View>
    <TextInput
    style={{
      height: 40,
      borderColor: 'gray',
      borderWidth: 1,
    }}
    defaultValue=" you can type me"
    />
    </ScrollView>
   
  );
};
export default App;
